<?
if( isset($_GET['delete']) ) {
	$proprieta 	= $_GET['delete'] ;
	$particella	= $_GET['particella'];
	
	list( $res , $id ) = cancellaPart($codice) ;
	
	if( $res ) 	echo "cancellazione avvenuta con successo ( codice $codice, particella $particella )" ;
	else 		echo "errore" ;
}
?>