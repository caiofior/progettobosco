<?php	
if( $page != 'main.php' and  $page != 'index.php'){
	echo "<div id='regione'>Regione ...</div><div id='logo'></div>";
}
else{
echo "<div id='isafa'></div> <div id='logo'></div><div id='iss'></div>";
}