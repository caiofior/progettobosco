
<div id='home'>

  <a class='main_button' id='bosco' href='?page=bosco'>Bosco</a>
  
  <a class='main_button' id='edp' href='?page=descrp'>Elaborazione descrizioni particellari</a>

  <a class='main_button' id='tavole' href='?page=tavole'>Tavole di cubatura</a>

  <a class='main_button' id='descrp' href='?page=descrp'>Descrizioni particellari</a>

  <a class='main_button' id='comprese' href='?'>Comprese/Classi colturali</a>

  <a class='main_button' id='dizionari' href='?page=dizionari'>Dizionari</a>

  <a class='main_button' id='daticat' href='?page=daticat'>Dati catastali</a>

  <a class='main_button' id='spazio' href='?'></a>

  <a class='main_button' id='strumenti' href='?'>Strumenti</a>

  <a class='main_button' id='rildend' href='?page=rildend'>Rilievi dendrometrici</a>

  <a class='main_button' id='elabdp' href='?'>Elaborazione dati dendrometrici</a>

  <a class='main_button' id='gsta' href='?'>Gestione stampe</a>

  <a class='main_button' id='viab' href='?page=viabilita'>Descrizioni viabilità</a>

  <a class='main_button' id='piano' href='?'>Piano degli interventi</a>

  <a class='main_button' id='decod' href='?'>Decodifica schede</a>

</div>
 