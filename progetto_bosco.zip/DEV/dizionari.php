<div id='home' class='descrp_big'>

	<div class='b_title'>Dizionari</div>
  <form name="dizionari_form" action="?page=dizionari" method="get"> 
	<div class='dizionari center'>
<?php
		echo "<a class='dizionari_picture'  href='?page=dizionari&scheda=arbo_arbu'>Specie Arboree/arbustive</a>" ;
		echo "<a class='dizionari_picture'  href='?page=dizionari&scheda=erbacee'>Specie Erbacee</a>" ;
		echo "<a class='dizionari_picture'  href='?page=dizionari&scheda=tipi_for'>Tipi Forestali</a>" ;
		echo "<a class='dizionari_picture'  href='?page=dizionari&scheda=rilev'>Rilevatori</a>" ;
		echo "<a class='dizionari_picture'  href='?page=dizionari&scheda=reg'>Regioni</a>" ;
		echo "<a class='dizionari_picture'  href='?page=dizionari&scheda=prov'>Province</a>" ;
		echo "<a class='dizionari_picture'  href='?page=dizionari&scheda=com_mont'>Comunità montane</a>" ;
		echo "<a class='dizionari_picture'  href='?page=dizionari&scheda=comuni'>Comuni</a>" ;
?>
	</div>
</form>
</div>