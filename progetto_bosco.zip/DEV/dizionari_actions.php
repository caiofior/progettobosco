<?php
$scheda= (isset($scheda) and $scheda == $_GET ['scheda']) ? $scheda = $_GET ['scheda'] : 'echo "Errore nella selezione dizionari"';


If ($scheda == 'arbo_arbu'){
// 	echo "<table><thead>";
// 	echo "<tr><th>codice</th><th colspan=3>nome</th><th>form_b</th><th>codice</th><th></th><th></th><th></th><th></th><th></th></tr> "
//       </thead>
// 
//       <tbody>
// 		      echo "<option  selected='selected'>particella...</option>" ;
// 	$alberi = getDizArbo;
// 	foreach ($alberi as $albero) {
// 		echo "<option value='".$particella->cod_part."'". $selected.">".$particella->cod_part."</option>\n" ;
// 		}
echo "ciao";
}

?>